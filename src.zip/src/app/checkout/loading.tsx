export default function Loading() {
  return (
    <div className="flex items-center justify-center py-20">
      <p>Đang tải...</p>
    </div>
  );
}
